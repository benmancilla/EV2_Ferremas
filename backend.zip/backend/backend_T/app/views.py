import uuid
import json
import requests
import traceback
from datetime import datetime, timedelta

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View

from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.permissions import IsAuthenticatedOrReadOnly

from transbank.webpay.webpay_plus.transaction import Transaction
from transbank.common.integration_type import IntegrationType

from django.db import transaction
from django.views.generic import TemplateView


from .models import React, Contact, UserProfile
from .serializer import ReactSerializer, ContactSerializer
from .permissions import IsAuthenticatedOrReadOnly

from transbank.webpay.webpay_plus.transaction import Transaction
from transbank.common.integration_type import IntegrationType

# Instancia global para integración
transaction = Transaction.build_for_integration(
    commerce_code='597055555532',
    api_key='579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C'
)

@csrf_exempt
def init_payment(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            amount = data.get('amount')

            if amount is None:
                return JsonResponse({'error': 'Amount is required'}, status=400)

            response = transaction.create(
                buy_order='order1234',
                session_id='session1234',
                amount=amount,
                return_url='http:localhost:5173/frontend-transversal/',
            )

            return JsonResponse({
                'url': response['url'],
                'token': response['token'],
            })
        except Exception as e:
            traceback.print_exc()
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid method'}, status=405)

#-----------------------------#

yesterday = (datetime.now() - timedelta(days=5)).strftime('%Y-%m-%d')
today = (datetime.now() - timedelta(days=4)).strftime('%Y-%m-%d')
user1 = 'ben.mancilla@duocuc.cl'
password1 = 'dW5S@T!eZY!h#pW'#--si si ya se --


class DolarPeso(APIView):
    def get(self, request):
        user = user1
        password = password1
        timeseries = 'F073.TCO.PRE.Z.D'

        params = {
            'user': user,
            'pass': password,
            'function': 'GetSeries',
            'timeseries': timeseries,
            'firstdate': yesterday,
            'lastdate': today,
        }

        url = 'https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx'

        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            return Response(data)
        except requests.RequestException as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class EuroPeso(APIView):
    def get(self, request):
        user = user1
        password = password1
        timeseries = 'F072.CLP.EUR.N.O.D'

        params = {
            'user': user,
            'pass': password,
            'function': 'GetSeries',
            'timeseries': timeseries,
            'firstdate': yesterday,
            'lastdate': today,
        }

        url = 'https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx'

        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            return Response(data)
        except requests.RequestException as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@csrf_exempt
def purchase(request):
    items = request.data.get('items', [])

    if not items:
        return Response({'error': 'No items provided'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        with transaction.atomic():
            for item in items:
                product = React.objects.select_for_update().get(id=item['id'])
                quantity = item.get('quantity', 0)

                if product.stock < quantity:
                    return Response({'error': f"Stock insuficiente para {product.title}"}, status=status.HTTP_400_BAD_REQUEST)

                product.stock -= quantity
                product.save()

    except React.DoesNotExist:
        return Response({'error': 'Producto no encontrado.'}, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({'error': f'Error inesperado: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response({'message': 'Compra realizada con éxito'}, status=status.HTTP_200_OK)


class PageView(TemplateView):
    template_name = 'app/template.html'


class ReactView(generics.ListCreateAPIView):
    queryset = React.objects.all()
    serializer_class = ReactSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


class ContactView(generics.ListCreateAPIView):
    queryset = Contact.objects.all()
    serializer_class = ContactSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@method_decorator(csrf_exempt, name='dispatch')
class RegisterView(View):
    def post(self, request):
        try:
            data = json.loads(request.body)
            full_name = data.get('full_name')
            email = data.get('email')
            password = data.get('password')

            if not full_name or not email or not password:
                return JsonResponse({'error': 'Todos los campos son obligatorios.'}, status=400)

            if UserProfile.objects.filter(email=email).exists():
                return JsonResponse({'error': 'El correo ya está registrado.'}, status=400)

            user = UserProfile(full_name=full_name, email=email)
            user.set_password(password)
            user.full_clean()
            user.save()

            return JsonResponse({'message': 'Usuario registrado exitosamente.'}, status=201)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class LoginView(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({'error': 'Email y contraseña son obligatorios.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = UserProfile.objects.get(email=email)
        except UserProfile.DoesNotExist:
            return Response({'error': 'Usuario no encontrado.'}, status=status.HTTP_400_BAD_REQUEST)

        if not user.check_password(password):
            return Response({'error': 'Contraseña incorrecta.'}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'message': 'Inicio de sesión exitoso.'}, status=status.HTTP_200_OK)
