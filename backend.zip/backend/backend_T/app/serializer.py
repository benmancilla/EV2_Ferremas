from rest_framework import serializers
from . models import React,Contact,UserProfile

class ReactSerializer(serializers.ModelSerializer):
    class Meta:
        model = React
        fields = ['id', 'title', 'image', 'price', 'stock']

class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = ['name', 'email', 'message', 'created_at']

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['id', 'full_name', 'email', 'password']
        extra_kwargs = {
            'password': {'write_only': True}
        }
