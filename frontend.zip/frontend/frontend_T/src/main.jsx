import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import Background from './components/bg';
import CreateNavBar from './components/nav';
import CreateSlider from './components/slider';
import CreateCardGroup from './components/cards';
import './index.css';
import './assets/css/nav.css';
import './assets/css/btn.css'
import './assets/css/more.css';
import'./assets/css/scroll.css';
import'./assets/css/final.css';
import'./assets/css/cart.css';

const App = () => (
  <React.Fragment>
    <section className={`bg-all ${Background()}`}>
      <CreateNavBar />
      <section className="presentation" id="presentation">
        <div className="info">
          <div className="info-text">
            <h1>Ferremas</h1>
            <p>
              FERREMAS es una distribuidora chilena con más de 40 años en el rubro de ferretería y construcción. Fundada en los años 80 en Santiago, actualmente opera con 7 sucursales en distintas regiones. Ofrece un amplio catálogo de herramientas, materiales eléctricos, pinturas y artículos de seguridad, trabajando con marcas reconocidas como Bosch, Makita, Stanley y Sika. Atiende tanto a empresas como a clientes particulares, destacando por la calidad de sus productos.
            </p>
          </div>
          <a type="button" className="btn btn-outline-info" id="trabajos-btn" href="#more-bg1">Más</a>
        </div>
        <CreateSlider />
      </section>

      <section className="more" id={`more-${Background()}`}>
        <div className={`info-all info-more-${Background()}`}>
          <div className="info-text-more">
            <h1 id='glow'>TODO EN HERRAMIENTAS</h1>
            <h2>
              Desde lo básico hasta lo profesional.
            </h2>
          </div>
        </div>
        <CreateCardGroup />
      </section>

      <div className="modal fade extra" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
              <button type="button" className="btn-close close-final" data-bs-dismiss="modal" aria-label="Close"></button>
            <div className="modal-body modal-final">

            </div>
          </div>
        </div>
      </div>
    </section>



    <div className="container">
      <footer className="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p className="col-md-4 mb-0 text-body-secondary">© 2025 Ferremas</p>
      </footer>
    </div>
  </React.Fragment>
);

ReactDOM.render(<App />, document.getElementById('root'));





