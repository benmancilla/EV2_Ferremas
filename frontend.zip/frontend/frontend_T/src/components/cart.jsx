import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import ShoppingCart from './ShoppingCart'; // tu componente carrito

const CreateCardGroup = () => {
  const [reacts, setReacts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [mode, setMode] = useState('md');
  const [chunkedReacts, setChunkedReacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch products
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await axios.get('http://127.0.0.1:8000/drawings/');
        setReacts(res.data);
        setError(null);
      } catch {
        setError('Error fetching data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Responsive mode
  useEffect(() => {
    const handleResize = () => setMode(window.innerWidth <= 426 ? 'sm' : 'md');
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Chunk products
  useEffect(() => {
    const chunk = (arr, size) => {
      return arr.reduce((acc, _, i) => {
        if (i % size === 0) acc.push(arr.slice(i, i + size));
        return acc;
      }, []);
    };
    setChunkedReacts(chunk(reacts, mode === 'sm' ? 1 : 3));
  }, [reacts, mode]);

  // Add product to cart
  const addToCart = (product) => {
    const productStock = reacts.find(p => p.id === product.id)?.stock || 0;
    const cartProduct = cartItems.find(p => p.id === product.id);
    if (cartProduct) {
      if (cartProduct.quantity >= productStock) {
        alert('No hay más stock disponible');
        return;
      }
      setCartItems(cartItems.map(item => 
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      if (productStock === 0) {
        alert('Producto sin stock');
        return;
      }
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  };

  // Increment quantity
  const incrementQuantity = (id) => {
    const stock = reacts.find(p => p.id === id)?.stock || 0;
    const item = cartItems.find(p => p.id === id);
    if (item && item.quantity < stock) {
      setCartItems(cartItems.map(p => p.id === id ? { ...p, quantity: p.quantity + 1 } : p));
    } else {
      alert('No hay más stock disponible');
    }
  };

  // Remove quantity
  const removeFromCart = (id) => {
    const item = cartItems.find(p => p.id === id);
    if (!item) return;

    if (item.quantity === 1) {
      setCartItems(cartItems.filter(p => p.id !== id));
    } else {
      setCartItems(cartItems.map(p => p.id === id ? { ...p, quantity: p.quantity - 1 } : p));
    }
  };

  // Total price
  const totalPrice = () => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);
  };

  // Handle purchase (example)
  const handlePurchase = async () => {
    if (cartItems.length === 0) {
      alert('El carrito está vacío');
      return;
    }
    try {
      const items = cartItems.map(({ id, quantity }) => ({ id, quantity }));
      const res = await axios.post('http://127.0.0.1:8000/purchase/', { items });
      alert(res.data.message || 'Compra realizada con éxito');
      setCartItems([]);
      // También cerrar modal si quieres, o cualquier otra acción
    } catch (err) {
      alert('Error en la compra');
      console.error(err);
    }
  };

  // Card component inline
  const CreateCard = ({ product }) => {
    const isOutOfStock = product.stock === 0;
    return (
      <div className="col">
        <div className="card">
          <img
            src={product.image}
            className="card-img-top"
            alt={product.title}
            onClick={() => window.open(product.image, '_blank')}
            style={{ cursor: 'pointer' }}
          />
          <div className="card-body">
            <h5 className="card-title">{product.title}</h5>
            <h5 className="card-title">${product.price}</h5>
            <p>{isOutOfStock ? 'Sin stock' : `Stock: ${product.stock}`}</p>
            <button
              className="btn btn-primary"
              onClick={() => addToCart(product)}
              disabled={isOutOfStock}
            >
              {isOutOfStock ? 'Agotado' : 'Agregar al carrito'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  if (loading) return <p>Cargando productos...</p>;
  if (error) return <p>{error}</p>;

  return (
    <>
      {/* Carousel */}
      <div id="card-carousel" className="carousel slide" data-bs-ride="carousel" data-bs-interval="7000">
        <div className="carousel-inner">
          {chunkedReacts.map((chunk, i) => (
            <div key={i} className={`carousel-item ${i === 0 ? 'active' : ''}`}>
              <div className="row row-cols-1 row-cols-md-3 g-4">
                {chunk.map(product => (
                  <CreateCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          ))}
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#card-carousel" data-bs-slide="prev">
          <span className="carousel-control-prev-icon"></span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#card-carousel" data-bs-slide="next">
          <span className="carousel-control-next-icon"></span>
        </button>
      </div>

      {/* Shopping Cart Modal */}
      <ShoppingCart
        cartItems={cartItems}
        setCartItems={setCartItems}
        totalPrice={totalPrice}
        incrementQuantity={incrementQuantity}
        removeFromCart={removeFromCart}
      />

      {/* Button to open cart modal */}
      <button
        type="button"
        className="btn btn-primary mt-3"
        data-bs-toggle="modal"
        data-bs-target="#cartModal"
      >
        Ver Carrito ({cartItems.length})
      </button>

      {/* Comprar button outside modal to trigger handlePurchase */}
      <div className="d-flex justify-content-center mt-3">
        <button
          className="btn btn-success"
          onClick={handlePurchase}
          disabled={cartItems.length === 0}
        >
          Finalizar Compra
        </button>
      </div>
    </>
  );
};

export default CreateCardGroup;
