import React from 'react';
import worker from '../assets/img/worker.jpg';
import hammer from '../assets/img/hammer.png';
import materials from '../assets/img/materials.jpg';

const CreateSlide = ({ link, img, alt }) => {
    return (
        <a href={link}>
            <img 
                src={img} 
                alt={alt} 
                className="d-block pintura-inicio" 
                style={{ width: '600px', height: '620px', objectFit: 'cover' }} 
            />
        </a>
    );
};

const CreateSlider = () => {
    return (
        <React.Fragment>
            <div id="carousel" className="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="10000">
                <div className="carousel-item active">
                    <CreateSlide link="#" img={worker} alt="worker" />
                </div>
                <div className="carousel-item">
                    <CreateSlide link="#" img={hammer} alt="hammer" />
                </div>
                <div className="carousel-item">
                    <CreateSlide link="#" img={materials} alt="materials" />
                </div>
            </div>
        </React.Fragment>
    );
};

export default CreateSlider;
