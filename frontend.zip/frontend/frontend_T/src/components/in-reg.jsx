import React, { useState } from 'react';
import axios from 'axios';
import bootstrap from 'bootstrap/dist/js/bootstrap.bundle.min.js';

const LoginForm = ({ setIsLoggedIn }) => {
    const [isRegister, setIsRegister] = useState(false);
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [formError, setFormError] = useState('');
    const [loading, setLoading] = useState(false);

    const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setFormError('');
        let isValid = true;

        if (email.trim() === '') {
        setEmailError('Por favor ingresa tu correo electrónico');
        isValid = false;
        } else if (!validateEmail(email)) {
        setEmailError('Por favor ingresa un correo válido');
        isValid = false;
        } else {
        setEmailError('');
        }

        if (password.trim() === '') {
        setPasswordError('Por favor ingresa tu contraseña');
        isValid = false;
        } else {
        setPasswordError('');
        }

        if (!isValid) return;

        setLoading(true);

        const url = isRegister
        ? 'http://127.0.0.1:8000/register/'
        : 'http://127.0.0.1:8000/login/';
        const payload = isRegister
        ? { full_name: fullName, email, password }
        : { email, password };

        try {
        const response = await axios.post(url, payload, {
            headers: { 'Content-Type': 'application/json' },
        });
        alert(response.data.message);

        if (isRegister) {
            setIsRegister(false);
            setFullName('');
        } else {
            // Login exitoso:
            setIsLoggedIn(true);

            // Cerrar modal LoginToggle usando Bootstrap JS
            const modalElement = document.getElementById('LoginToggle');
            const modalInstance =
            bootstrap.Modal.getInstance(modalElement) ||
            new bootstrap.Modal(modalElement);
            modalInstance.hide();
        }
        } catch (error) {
        if (error.response) {
            setFormError(error.response.data.error || 'Error al enviar el formulario');
        } else {
            setFormError('No se pudo conectar con el servidor');
        }
        } finally {
        setLoading(false);
        }
    };

    return (
        <div className="modal-body">
        <form onSubmit={handleSubmit} noValidate>
            {isRegister && (
            <div className="mb-3">
                <label htmlFor="InputFullName" className="form-label">Nombre completo</label>
                <input
                id="InputFullName"
                type="text"
                className="form-control"
                name="fullName"
                placeholder="Juan Pérez"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                />
            </div>
            )}
            <div className="mb-3">
            <label htmlFor="InputEmail" className="form-label">Email</label>
            <input
                id="InputEmail"
                type="email"
                className="form-control"
                name="email"
                placeholder="correo@ejemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            />
            <span className="text-danger">{emailError}</span>
            </div>
            <div className="mb-3">
            <label htmlFor="InputPassword" className="form-label">Contraseña</label>
            <input
                id="InputPassword"
                type="password"
                className="form-control"
                name="password"
                placeholder="********"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <span className="text-danger">{passwordError}</span>
            </div>
            {formError && <div className="alert alert-danger">{formError}</div>}
            <div className="modal-footer">
            <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading
                ? isRegister
                    ? 'Registrando...'
                    : 'Ingresando...'
                : isRegister
                ? 'Registrarse'
                : 'Iniciar sesión'}
            </button>
            </div>
            <div className="text-center mt-2">
            <span>
                {isRegister ? '¿Ya tienes una cuenta?' : '¿No tienes una cuenta?'}{' '}
                <button
                type="button"
                className="btn btn-link p-0"
                onClick={() => setIsRegister(!isRegister)}
                >
                {isRegister ? 'Inicia sesión' : 'Regístrate'}
                </button>
            </span>
            </div>
        </form>
        </div>
    );
};

export default LoginForm;
