import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import trash from '../assets/img/trash.svg';

const ShoppingCart = ({
  cartItems,
  setCartItems,
  totalPrice,
  incrementQuantity,
  removeFromCart,
  onPurchase,
  currency,
  tipoCambio,
  tipoCambioEuro,
}) => {
  const displayPrice = (price) => {
    if (currency === 'CLP') return `$${price} CLP`;
    if (currency === 'USD' && tipoCambio) return `$${(price / tipoCambio).toFixed(2)} USD`;
    if (currency === 'EUR' && tipoCambioEuro) return `€${(price / tipoCambioEuro).toFixed(2)} EUR`;
    return `$${price} CLP`;
  };

  const displayTotal = () => {
    const total = totalPrice();
    if (currency === 'CLP') return `$${total} CLP`;
    if (currency === 'USD' && tipoCambio) return `$${(total / tipoCambio).toFixed(2)} USD`;
    if (currency === 'EUR' && tipoCambioEuro) return `€${(total / tipoCambioEuro).toFixed(2)} EUR`;
    return `$${total} CLP`;
  };

  return (
    <div
      className="modal fade"
      id="cartModal"
      tabIndex="-1"
      aria-labelledby="cartModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <div className="modal-header" id="cart-top">
            <h5 className="modal-title" id="cartModalLabel">Carrito de Compras</h5>
            <button type="button" className="btn" data-bs-dismiss="modal">Seguir comprando</button>
          </div>
          <div className="modal-body">
            <ul className="list-unstyled">
              {cartItems.map((item, index) => (
                <li key={index} className="d-flex align-items-center mb-3">
                  <img src={item.img} alt={item.name} width={60} />
                  <div className="ms-3">
                    <div>
                      {item.name} {displayPrice(item.price)}
                    </div>
                    <div>cantidad: {item.quantity}</div>
                    <button className="btn cartbtn" onClick={() => incrementQuantity(item.id)}>+</button>
                    <button className="btn cartbtn" onClick={() => removeFromCart(item.id)}>-</button>
                    <button className="btn cartbtn" onClick={() =>
                      setCartItems(cartItems.filter((_, i) => i !== index))}>
                      <img src={trash} width={20} alt="Eliminar" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="modal-footer">
            <div>
              Total: {displayTotal()}
            </div>
          </div>
          <div className="modal-footer" id="cart-footer">
            <button className="btn trash-btn" onClick={() => setCartItems([])}>Vaciar carrito</button>
            <button className="btn btn-danger" onClick={onPurchase}>Finalizar Compra</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const CreateCard = ({ idProduct, img, name, alt, price, stock, onAddToCart, currency, tipoCambio,tipoCambioEuro }) => {
  const isOutOfStock = stock === 0;

  const displayPrice = currency === 'CLP'
    ? `$${price} CLP`
    : currency === 'USD' && tipoCambio
      ? `$${(price / tipoCambio).toFixed(2)} USD`
      : currency === 'EUR' && tipoCambioEuro
        ? `€${(price / tipoCambioEuro).toFixed(2)} EUR`
        : `$${price} CLP`;

  return (
    <div className="col">
      <div className="card">
        <img
          src={img}
          className="card-img-top"
          id="card-paint"
          alt={alt}
          onClick={() => window.open(img, '_blank')}
          style={{ cursor: 'pointer' }}
        />
        <div className="card-body">
          <h5 className="card-title">{name}</h5>
          <h5 className="card-title">{displayPrice}</h5>
          <p className="card-text">
            {isOutOfStock ? 'Sin stock' : `Stock: ${stock}`}
          </p>
          <button
            className="btn btn-primary"
            id="add-cart"
            onClick={() => onAddToCart({ id: idProduct, img, name, price })}
            disabled={isOutOfStock}
          >
            {isOutOfStock ? 'Agotado' : 'Agregar al Carrito'}
          </button>
        </div>
      </div>
    </div>
  );
};

const CreateCardGroup = () => {
  const [reacts, setReacts] = useState([]);
  const [chunkedReacts, setChunkedReacts] = useState([]);
  const [mode, setMode] = useState('md');
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tipoCambio, setTipoCambio] = useState(null);
  const [tipoCambioEuro, setTipoCambioEuro] = useState(null);
  const [currency, setCurrency] = useState('CLP'); // moneda activa

  useEffect(() => {
    const fetchReactData = async () => {
      try {
        setLoading(true);
        const response = await axios.get('http://127.0.0.1:8000/drawings/');
        setReacts(response.data);
        setError(null);
      } catch (err) {
        setError('Error fetching data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchReactData();
  }, []);

  useEffect(() => {
    const fetchTipoCambio = async () => {
      try {
        const res = await axios.get('http://localhost:8000/api/Dolar-Peso/');
        const observaciones = res.data.Series?.Obs;

        if (observaciones && observaciones.length > 0) {
          const valorMasReciente = observaciones[observaciones.length - 1].value;
          setTipoCambio(valorMasReciente);
        } else {
          console.warn('No se encontraron observaciones en la respuesta');
        }

        const resEuro = await axios.get('http://localhost:8000/api/Euro-Peso/');
        const obsEuro = resEuro.data.Series?.Obs;
        if (obsEuro && obsEuro.length > 0) {
          const valorMasRecienteEuro = obsEuro[obsEuro.length - 1].value;
          setTipoCambioEuro(valorMasRecienteEuro);
        } else {
          console.warn('No se encontraron observaciones Euro en la respuesta');
        }
      } catch (err) {
        console.error('Error obteniendo el tipo de cambio:', err);
      }
    };

    fetchTipoCambio();
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setMode(window.innerWidth <= 426 ? 'sm' : 'md');
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const chunkArray = (array, size) =>
      array.reduce((acc, _, index) => {
        if (index % size === 0) {
          acc.push(array.slice(index, index + size));
        }
        return acc;
      }, []);

    const chunkSize = mode === 'sm' ? 1 : 3;
    setChunkedReacts(chunkArray(reacts, chunkSize));
  }, [reacts, mode]);

  const addToCart = useCallback((product) => {
    const existingProduct = cartItems.find((item) => item.id === product.id);
    const productData = reacts.find((item) => item.id === product.id);

    if (!productData || productData.stock === 0) {
      alert('Este producto está agotado.');
      return;
    }

    if (existingProduct) {
      if (existingProduct.quantity >= productData.stock) {
        alert('No hay más stock disponible para este producto.');
        return;
      }
      const updatedCart = cartItems.map((item) =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      setCartItems(updatedCart);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  }, [cartItems, reacts]);

  const removeFromCart = useCallback((productId) => {
    const updatedCart = cartItems.map((item) =>
      item.id === productId
        ? { ...item, quantity: Math.max(0, item.quantity - 1) }
        : item
    );

    const filteredCart = updatedCart.filter((item) => item.quantity > 0);
    setCartItems(filteredCart);
  }, [cartItems]);

  const incrementQuantity = useCallback((productId) => {
    const productData = reacts.find((item) => item.id === productId);
    const existingProduct = cartItems.find((item) => item.id === productId);

    if (!productData || !existingProduct) return;

    if (existingProduct.quantity >= productData.stock) {
      alert('No hay más stock disponible para este producto.');
      return;
    }

    const updatedCart = cartItems.map((item) =>
      item.id === productId ? { ...item, quantity: item.quantity + 1 } : item
    );
    setCartItems(updatedCart);
  }, [cartItems, reacts]);

  const totalPrice = useCallback(() => {
    let total = 0;
    cartItems.forEach((product) => {
      total += parseFloat(product.price) * product.quantity;
    });
    return total.toFixed(2);
  }, [cartItems]);

  const handlePurchase = async () => {
    if (cartItems.length === 0) {
      alert('El carrito está vacío');
      return;
    }
    try {
      const amount = parseFloat(totalPrice()); // Total de la compra
      const response = await axios.post('http://localhost:8000/webpay/init/', { amount });

      const { url, token } = response.data;

      // Crear formulario y enviar para redirigir a Webpay
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = url;

      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'token_ws';
      input.value = token;

      form.appendChild(input);
      document.body.appendChild(form);
      form.submit();

    } catch (error) {
      alert('Error iniciando pago');
      console.error(error);
    }
  };


  if (loading) return <p>Cargando productos...</p>;
  if (error) return <p>{error}</p>;

  return (
    <>
      <div className="mb-3 text-end">
        <label htmlFor="currencySelect" className="me-2">Moneda:</label>
        <select
          id="currencySelect"
          className="form-select d-inline-block w-auto"
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
        >
          <option value="CLP">CLP - Pesos Chilenos</option>
          <option value="USD">USD - Dólares</option>
          <option value="EUR">EUR - EUROS</option>
          {/* Puedes agregar más opciones aquí */}
        </select>
    </div>

      <div
        id="card-carousel"
        className="carousel slide"
        data-bs-ride="carousel"
        data-bs-interval="7000"
      >
        <div className="carousel-inner">
          {chunkedReacts.map((chunk, index) => (
            <div
              key={chunk[0]?.id || index}
              className={`carousel-item ${index === 0 ? 'active' : ''}`}
            >
              <div className="row row-cols-1 row-cols-md-3 g-4" id="info">
                {chunk.map((react) => (
                  <CreateCard
                    key={react.id}
                    idProduct={react.id}
                    img={react.image}
                    name={react.title}
                    alt={react.title}
                    price={react.price}
                    stock={react.stock}
                    onAddToCart={addToCart}
                    currency={currency}
                    tipoCambio={tipoCambio}
                    tipoCambioEuro={tipoCambioEuro}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
        <button
          className="carousel-control-prev carousel-btn"
          type="button"
          data-bs-target="#card-carousel"
          data-bs-slide="prev"
        >
          <span className="carousel-control-prev-icon" aria-hidden="true" />
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next carousel-btn"
          type="button"
          data-bs-target="#card-carousel"
          data-bs-slide="next"
        >
          <span className="carousel-control-next-icon" aria-hidden="true" />
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      <ShoppingCart
        cartItems={cartItems}
        setCartItems={setCartItems}
        totalPrice={totalPrice}
        incrementQuantity={incrementQuantity}
        removeFromCart={removeFromCart}
        onPurchase={handlePurchase}
        currency={currency}
        tipoCambio={tipoCambio}
        tipoCambioEuro={tipoCambioEuro}
      />
    </>
  );
};

export default CreateCardGroup;
